﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Pmatrizes
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Botao1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";

            for( var i = 0; i <20; i++)
            {
                auxiliar = Interaction.InputBox($"Digite numero {i+1}", " Entrada de Dados");

                if(auxiliar == "")
                {
                    return; 
                }

                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Valor Erroneo");
                    i = i - 1;
                }
                
            }
            // reverse 
            Array.Reverse(vetor);
            auxiliar = "";
            foreach (var x in vetor)
                auxiliar += x + "\n";

            MessageBox.Show(auxiliar);


        }

        private void Botao2_Click(object sender, EventArgs e)
        {
            double[,] notas = new double [20 , 3];
            double[] soma = new double[20];
            

            string notaAluno;
            
            for ( var aluno = 0; aluno <20; aluno++)
            {
                for (var nota = 0; nota < 3; nota++)
                {
                    notaAluno = Interaction.InputBox($"Digite a nota {nota + 1} do aluno {aluno + 1}", " Entrada de Dados");


                    if (notaAluno == "")
                    {
                        return;
                    }

                    if (!double.TryParse(notaAluno, out notas[aluno, nota]))
                    {
                        MessageBox.Show("Valor Erroneo");
                        nota = nota - 1;
                    }
                    else if (notas[aluno, nota] < 0 || notas[aluno, nota] > 10)
                    {
                        MessageBox.Show("Valor Erroneo");
                        nota = nota - 1;
                    }

                else
                    {
                        soma[aluno] = soma[aluno] + notas[aluno, nota];
                    }





                }

                soma[aluno] = soma[aluno] / 3;
            }

            for (var aluno=0; aluno<20; aluno++)
            {
                MessageBox.Show($"Media do aluno {aluno + 1} foi :" + soma[aluno].ToString("N2"));

           
            }
        }

        private void Botao3_Click(object sender, EventArgs e)
        {
            string[] Alunos = { "Viviane", "Andre", "Helio", "Denise","Junior","Leonardo","Jose",
            "Nelma","Tobby" };

            Int32 I, Total = 0;
            Int32 N = Alunos.Length;
            for( I = 0; I < N-1; I++)
            {
                Total += Alunos[I].Length;
            }

            MessageBox.Show(Total.ToString());
        }

        private void Botao4_Click(object sender, EventArgs e)
        {
            ArrayList alunera = new ArrayList();

            alunera.Add("Ana");
            alunera.Add("André");
            alunera.Add("Débora");
            alunera.Add("Fátima");
            alunera.Add("João");
            alunera.Add("Janete");
            alunera.Add("Otávio");
            alunera.Add("Marcelo");
            alunera.Add("Pedro");
            alunera.Add("Tais");

            alunera.Remove("Otávio");

            string result = "Alunos desta classe:\n";
            foreach (var item in alunera)
            {
                result += item.ToString() + "\n";
            }

            MessageBox.Show(result);

        }
    }
}
