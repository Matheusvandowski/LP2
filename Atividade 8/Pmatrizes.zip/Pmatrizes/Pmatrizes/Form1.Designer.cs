﻿namespace Pmatrizes
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.Botao1 = new System.Windows.Forms.Button();
            this.Botao2 = new System.Windows.Forms.Button();
            this.Botao3 = new System.Windows.Forms.Button();
            this.Botao4 = new System.Windows.Forms.Button();
            this.Botao5 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // Botao1
            // 
            this.Botao1.Location = new System.Drawing.Point(93, 95);
            this.Botao1.Name = "Botao1";
            this.Botao1.Size = new System.Drawing.Size(151, 75);
            this.Botao1.TabIndex = 0;
            this.Botao1.Text = "Exercicio 1";
            this.Botao1.UseVisualStyleBackColor = true;
            this.Botao1.Click += new System.EventHandler(this.Botao1_Click);
            // 
            // Botao2
            // 
            this.Botao2.Location = new System.Drawing.Point(341, 95);
            this.Botao2.Name = "Botao2";
            this.Botao2.Size = new System.Drawing.Size(151, 75);
            this.Botao2.TabIndex = 1;
            this.Botao2.Text = "Exercicio 2";
            this.Botao2.UseVisualStyleBackColor = true;
            this.Botao2.Click += new System.EventHandler(this.Botao2_Click);
            // 
            // Botao3
            // 
            this.Botao3.Location = new System.Drawing.Point(572, 95);
            this.Botao3.Name = "Botao3";
            this.Botao3.Size = new System.Drawing.Size(151, 75);
            this.Botao3.TabIndex = 2;
            this.Botao3.Text = "Exercicio 3";
            this.Botao3.UseVisualStyleBackColor = true;
            this.Botao3.Click += new System.EventHandler(this.Botao3_Click);
            // 
            // Botao4
            // 
            this.Botao4.Location = new System.Drawing.Point(221, 245);
            this.Botao4.Name = "Botao4";
            this.Botao4.Size = new System.Drawing.Size(151, 75);
            this.Botao4.TabIndex = 3;
            this.Botao4.Text = "Exercicio 4";
            this.Botao4.UseVisualStyleBackColor = true;
            this.Botao4.Click += new System.EventHandler(this.Botao4_Click);
            // 
            // Botao5
            // 
            this.Botao5.Location = new System.Drawing.Point(458, 245);
            this.Botao5.Name = "Botao5";
            this.Botao5.Size = new System.Drawing.Size(151, 75);
            this.Botao5.TabIndex = 4;
            this.Botao5.Text = "Exercicio 5";
            this.Botao5.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(927, 450);
            this.Controls.Add(this.Botao5);
            this.Controls.Add(this.Botao4);
            this.Controls.Add(this.Botao3);
            this.Controls.Add(this.Botao2);
            this.Controls.Add(this.Botao1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button Botao1;
        private System.Windows.Forms.Button Botao2;
        private System.Windows.Forms.Button Botao3;
        private System.Windows.Forms.Button Botao4;
        private System.Windows.Forms.Button Botao5;
    }
}

