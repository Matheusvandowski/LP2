﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Globalization;

namespace ProvaAlvesAugusto
{
    public partial class Form1 : Form
    {
        string entradaVendas;
        double[,] vendas= new double[3, 4];
        double[] soma = new double[4];
        double somaGeral = 0;

        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {
                    entradaVendas = Interaction.InputBox($"Insira o valor de venda do Mês {i + 1} da semana {j+1} :");
                    if (!Double.TryParse(entradaVendas, out vendas[i, j]))
                    {
                        MessageBox.Show("Digite um Numero");
                        j--;
                    }

                        if (vendas[i, j] <= 0)
                    {
                        MessageBox.Show("valor inválido");
                        j--;
                    }

                    else
                    {
                        soma[i] = vendas[i, j] + soma[i];
                    }
                                       
                }

                somaGeral = soma[i] + somaGeral;
            }


            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                {

                    string aux = $"Total do mês {i+1} Semana {j+1}: R${vendas[i, j].ToString("F2")}";
                    lbox1.Items.Add(aux);



                }

                string aux1 = $"\nTotal do mês {i+1}: R$ {soma[i].ToString("F2")}";
                lbox1.Items.Add(aux1);

            }

            string aux2 = $"\n\n Total Geral: R$ {somaGeral.ToString("F2")}";
            lbox1.Items.Add(aux2);
        }
    }
    
 }

