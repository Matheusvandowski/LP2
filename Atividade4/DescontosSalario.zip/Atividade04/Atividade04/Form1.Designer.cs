﻿namespace Atividade04
{
    partial class txtbSalBruto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lbl1 = new System.Windows.Forms.Label();
            this.lbl2 = new System.Windows.Forms.Label();
            this.lbl3 = new System.Windows.Forms.Label();
            this.lbl4 = new System.Windows.Forms.Label();
            this.lbl5 = new System.Windows.Forms.Label();
            this.lbl6 = new System.Windows.Forms.Label();
            this.lbl7 = new System.Windows.Forms.Label();
            this.lbl8 = new System.Windows.Forms.Label();
            this.lbl9 = new System.Windows.Forms.Label();
            this.mskdBruto = new System.Windows.Forms.MaskedTextBox();
            this.nudNumFilhos = new System.Windows.Forms.NumericUpDown();
            this.btnDesconto = new System.Windows.Forms.Button();
            this.mskNome = new System.Windows.Forms.MaskedTextBox();
            this.mskINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskIRPF = new System.Windows.Forms.MaskedTextBox();
            this.mskFamilia = new System.Windows.Forms.MaskedTextBox();
            this.mskLiquido = new System.Windows.Forms.MaskedTextBox();
            this.mskDescINSS = new System.Windows.Forms.MaskedTextBox();
            this.mskDescIRPF = new System.Windows.Forms.MaskedTextBox();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nudNumFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.Location = new System.Drawing.Point(67, 86);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(142, 20);
            this.lbl1.TabIndex = 0;
            this.lbl1.Text = "Nome Funcionario:";
            this.lbl1.Click += new System.EventHandler(this.Label1_Click);
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.Location = new System.Drawing.Point(68, 129);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(105, 20);
            this.lbl2.TabIndex = 1;
            this.lbl2.Text = "Salario Bruto:";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.Location = new System.Drawing.Point(68, 173);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(137, 20);
            this.lbl3.TabIndex = 2;
            this.lbl3.Text = "Numero de Filhos:";
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.Location = new System.Drawing.Point(67, 254);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(109, 20);
            this.lbl4.TabIndex = 3;
            this.lbl4.Text = "Aliquota INSS";
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.Location = new System.Drawing.Point(67, 293);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(108, 20);
            this.lbl5.TabIndex = 4;
            this.lbl5.Text = "Aliquota IRPF";
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6.Location = new System.Drawing.Point(67, 338);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(116, 20);
            this.lbl6.TabIndex = 5;
            this.lbl6.Text = "Salario Familia:";
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7.Location = new System.Drawing.Point(67, 376);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(117, 20);
            this.lbl7.TabIndex = 6;
            this.lbl7.Text = "Salario Liquido:";
            // 
            // lbl8
            // 
            this.lbl8.AutoSize = true;
            this.lbl8.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl8.Location = new System.Drawing.Point(593, 254);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(124, 20);
            this.lbl8.TabIndex = 7;
            this.lbl8.Text = "Desconto INSS:";
            // 
            // lbl9
            // 
            this.lbl9.AutoSize = true;
            this.lbl9.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl9.Location = new System.Drawing.Point(593, 293);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(119, 20);
            this.lbl9.TabIndex = 8;
            this.lbl9.Text = "Desconto IRPF";
            // 
            // mskdBruto
            // 
            this.mskdBruto.Location = new System.Drawing.Point(231, 127);
            this.mskdBruto.Mask = "90000.00";
            this.mskdBruto.Name = "mskdBruto";
            this.mskdBruto.Size = new System.Drawing.Size(61, 20);
            this.mskdBruto.TabIndex = 16;
            // 
            // nudNumFilhos
            // 
            this.nudNumFilhos.Location = new System.Drawing.Point(231, 171);
            this.nudNumFilhos.Name = "nudNumFilhos";
            this.nudNumFilhos.Size = new System.Drawing.Size(120, 20);
            this.nudNumFilhos.TabIndex = 17;
            // 
            // btnDesconto
            // 
            this.btnDesconto.Location = new System.Drawing.Point(295, 213);
            this.btnDesconto.Name = "btnDesconto";
            this.btnDesconto.Size = new System.Drawing.Size(168, 23);
            this.btnDesconto.TabIndex = 18;
            this.btnDesconto.Text = "Verificar Desconto";
            this.btnDesconto.UseVisualStyleBackColor = true;
            this.btnDesconto.Click += new System.EventHandler(this.BtnDesconto_Click);
            // 
            // mskNome
            // 
            this.mskNome.Location = new System.Drawing.Point(231, 88);
            this.mskNome.Name = "mskNome";
            this.mskNome.Size = new System.Drawing.Size(316, 20);
            this.mskNome.TabIndex = 19;
            // 
            // mskINSS
            // 
            this.mskINSS.Location = new System.Drawing.Point(240, 254);
            this.mskINSS.Name = "mskINSS";
            this.mskINSS.ReadOnly = true;
            this.mskINSS.Size = new System.Drawing.Size(316, 20);
            this.mskINSS.TabIndex = 20;
            // 
            // mskIRPF
            // 
            this.mskIRPF.Location = new System.Drawing.Point(240, 295);
            this.mskIRPF.Name = "mskIRPF";
            this.mskIRPF.ReadOnly = true;
            this.mskIRPF.Size = new System.Drawing.Size(316, 20);
            this.mskIRPF.TabIndex = 21;
            // 
            // mskFamilia
            // 
            this.mskFamilia.Location = new System.Drawing.Point(240, 338);
            this.mskFamilia.Name = "mskFamilia";
            this.mskFamilia.ReadOnly = true;
            this.mskFamilia.Size = new System.Drawing.Size(316, 20);
            this.mskFamilia.TabIndex = 22;
            // 
            // mskLiquido
            // 
            this.mskLiquido.Location = new System.Drawing.Point(240, 378);
            this.mskLiquido.Name = "mskLiquido";
            this.mskLiquido.ReadOnly = true;
            this.mskLiquido.Size = new System.Drawing.Size(316, 20);
            this.mskLiquido.TabIndex = 23;
            // 
            // mskDescINSS
            // 
            this.mskDescINSS.Location = new System.Drawing.Point(740, 254);
            this.mskDescINSS.Name = "mskDescINSS";
            this.mskDescINSS.ReadOnly = true;
            this.mskDescINSS.Size = new System.Drawing.Size(316, 20);
            this.mskDescINSS.TabIndex = 24;
            // 
            // mskDescIRPF
            // 
            this.mskDescIRPF.Location = new System.Drawing.Point(740, 295);
            this.mskDescIRPF.Name = "mskDescIRPF";
            this.mskDescIRPF.ReadOnly = true;
            this.mskDescIRPF.Size = new System.Drawing.Size(316, 20);
            this.mskDescIRPF.TabIndex = 25;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(295, 442);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(168, 23);
            this.btnLimpar.TabIndex = 26;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(526, 442);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(168, 23);
            this.btnSair.TabIndex = 27;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // txtbSalBruto
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1275, 497);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.mskDescIRPF);
            this.Controls.Add(this.mskDescINSS);
            this.Controls.Add(this.mskLiquido);
            this.Controls.Add(this.mskFamilia);
            this.Controls.Add(this.mskIRPF);
            this.Controls.Add(this.mskINSS);
            this.Controls.Add(this.mskNome);
            this.Controls.Add(this.btnDesconto);
            this.Controls.Add(this.nudNumFilhos);
            this.Controls.Add(this.mskdBruto);
            this.Controls.Add(this.lbl9);
            this.Controls.Add(this.lbl8);
            this.Controls.Add(this.lbl7);
            this.Controls.Add(this.lbl6);
            this.Controls.Add(this.lbl5);
            this.Controls.Add(this.lbl4);
            this.Controls.Add(this.lbl3);
            this.Controls.Add(this.lbl2);
            this.Controls.Add(this.lbl1);
            this.Name = "txtbSalBruto";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.nudNumFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl1;
        private System.Windows.Forms.Label lbl2;
        private System.Windows.Forms.Label lbl3;
        private System.Windows.Forms.Label lbl4;
        private System.Windows.Forms.Label lbl5;
        private System.Windows.Forms.Label lbl6;
        private System.Windows.Forms.Label lbl7;
        private System.Windows.Forms.Label lbl8;
        private System.Windows.Forms.Label lbl9;
        private System.Windows.Forms.MaskedTextBox mskdBruto;
        private System.Windows.Forms.NumericUpDown nudNumFilhos;
        private System.Windows.Forms.Button btnDesconto;
        private System.Windows.Forms.MaskedTextBox mskNome;
        private System.Windows.Forms.MaskedTextBox mskINSS;
        private System.Windows.Forms.MaskedTextBox mskIRPF;
        private System.Windows.Forms.MaskedTextBox mskFamilia;
        private System.Windows.Forms.MaskedTextBox mskLiquido;
        private System.Windows.Forms.MaskedTextBox mskDescINSS;
        private System.Windows.Forms.MaskedTextBox mskDescIRPF;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
    }
}

