﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade04
{
    public partial class txtbSalBruto : Form
    {
        public txtbSalBruto()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void BtnDesconto_Click(object sender, EventArgs e)
        {
            double SalBruto;
            double Familia, Liquido, DescINSS, DescIRPF, Filhos;

            double.TryParse(nudNumFilhos.Text, out Filhos);


            if(!double.TryParse(mskdBruto.Text, out SalBruto)) // verifica se salario esta em double
            {
                MessageBox.Show("Digite o Salário corretamente");
            }

            if(mskNome.Text == "") // verifica se nome não esta em branco
            {
                MessageBox.Show("Digite o nome do Funcionario Corretamente");
            }

            if(SalBruto <= 800.47) // calculo de faixa de aliquota
            {
                DescINSS = SalBruto * 0.0765;
                mskDescINSS.Text = DescINSS.ToString("F2");
                mskINSS.Text = "7.65%";
                
            }
                else if(SalBruto <= 1050)
                {
                     DescINSS = SalBruto * 0.0865;
                     mskDescINSS.Text = DescINSS.ToString("F2");
                     mskINSS.Text = "8.65%";
            }
                 else if (SalBruto <= 1400.77)
                 {
                      DescINSS = SalBruto * 0.09;
                      mskDescINSS.Text = DescINSS.ToString("F2");
                      mskINSS.Text = "9%";
                 }
                    else if (SalBruto <= 2801.56)
                    {
                        DescINSS = SalBruto * 0.11;
                        mskDescINSS.Text = DescINSS.ToString("F2");
                        mskINSS.Text = "11%";
                    }
                        else
                        {
                             DescINSS = 308.17;
                            mskDescINSS.Text = DescINSS.ToString("F2");
                            mskINSS.Text = "Teto";
                        }


            if(SalBruto <= 1257.12) // calculo faixa imposto de renda 
            {
                DescIRPF = 0.0;
                mskDescIRPF.Text = DescIRPF.ToString("F2");
                mskIRPF.Text = "Isento";
            }
                else if(SalBruto <= 2512.08)
                {
                    DescIRPF = SalBruto * 0.15;
                    mskIRPF.Text = DescIRPF.ToString("F2");
                    mskIRPF.Text = "15%";
                }
                    else
                    {
                       DescIRPF = SalBruto * 0.275;
                       mskDescIRPF.Text = DescIRPF.ToString("F2");
                       mskIRPF.Text = "27.5%";
                    }



            if (SalBruto <= 435.52) // calculo auxilio familia baixa renda
            {
                Familia = Filhos * 22.33;
                mskFamilia.Text = Familia.ToString("F2");
            }
                else if (SalBruto <= 654.61)
                {
                    Familia = Filhos * 15.74;
                    mskFamilia.Text = Familia.ToString("F2");
                }
                    else
                    {
                        Familia = 0;
                        mskFamilia.Text = Familia.ToString("F2");
                    }

            Liquido = SalBruto - DescINSS - DescIRPF + Familia;
            mskLiquido.Text = Liquido.ToString();


        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskNome.Clear();
            mskdBruto.Clear();
            mskDescINSS.Clear();
            mskDescIRPF.Clear();
            mskFamilia.Clear();
            mskLiquido.Clear();
            mskDescINSS.Clear();
            mskDescIRPF.Clear();          

            
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
