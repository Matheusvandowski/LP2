﻿namespace Aula3exercicio3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.lblLadoa = new System.Windows.Forms.Label();
            this.mskdboxLadoa = new System.Windows.Forms.MaskedTextBox();
            this.mskdboxLadob = new System.Windows.Forms.MaskedTextBox();
            this.lblLadob = new System.Windows.Forms.Label();
            this.mskdboxLadoc = new System.Windows.Forms.MaskedTextBox();
            this.lblLadoc = new System.Windows.Forms.Label();
            this.btnCalcular = new System.Windows.Forms.Button();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider2 = new System.Windows.Forms.ErrorProvider(this.components);
            this.errorProvider3 = new System.Windows.Forms.ErrorProvider(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).BeginInit();
            this.SuspendLayout();
            // 
            // lblLadoa
            // 
            this.lblLadoa.AutoSize = true;
            this.lblLadoa.Location = new System.Drawing.Point(244, 120);
            this.lblLadoa.Name = "lblLadoa";
            this.lblLadoa.Size = new System.Drawing.Size(64, 20);
            this.lblLadoa.TabIndex = 0;
            this.lblLadoa.Text = "Lado A:";
            // 
            // mskdboxLadoa
            // 
            this.mskdboxLadoa.Location = new System.Drawing.Point(363, 113);
            this.mskdboxLadoa.Name = "mskdboxLadoa";
            this.mskdboxLadoa.Size = new System.Drawing.Size(169, 26);
            this.mskdboxLadoa.TabIndex = 1;
            this.mskdboxLadoa.Validated += new System.EventHandler(this.MskdboxLadoa_Validated);
            // 
            // mskdboxLadob
            // 
            this.mskdboxLadob.Location = new System.Drawing.Point(363, 178);
            this.mskdboxLadob.Name = "mskdboxLadob";
            this.mskdboxLadob.Size = new System.Drawing.Size(169, 26);
            this.mskdboxLadob.TabIndex = 3;
            this.mskdboxLadob.Validated += new System.EventHandler(this.MskdboxLadob_Validated);
            // 
            // lblLadob
            // 
            this.lblLadob.AutoSize = true;
            this.lblLadob.Location = new System.Drawing.Point(244, 185);
            this.lblLadob.Name = "lblLadob";
            this.lblLadob.Size = new System.Drawing.Size(64, 20);
            this.lblLadob.TabIndex = 2;
            this.lblLadob.Text = "Lado B:";
            // 
            // mskdboxLadoc
            // 
            this.mskdboxLadoc.Location = new System.Drawing.Point(363, 245);
            this.mskdboxLadoc.Name = "mskdboxLadoc";
            this.mskdboxLadoc.Size = new System.Drawing.Size(169, 26);
            this.mskdboxLadoc.TabIndex = 5;
            this.mskdboxLadoc.Validated += new System.EventHandler(this.MskdboxLadoc_Validated);
            // 
            // lblLadoc
            // 
            this.lblLadoc.AutoSize = true;
            this.lblLadoc.Location = new System.Drawing.Point(244, 252);
            this.lblLadoc.Name = "lblLadoc";
            this.lblLadoc.Size = new System.Drawing.Size(64, 20);
            this.lblLadoc.TabIndex = 4;
            this.lblLadoc.Text = "Lado C:";
            // 
            // btnCalcular
            // 
            this.btnCalcular.Location = new System.Drawing.Point(608, 93);
            this.btnCalcular.Name = "btnCalcular";
            this.btnCalcular.Size = new System.Drawing.Size(94, 47);
            this.btnCalcular.TabIndex = 6;
            this.btnCalcular.Text = "Calcular";
            this.btnCalcular.UseVisualStyleBackColor = true;
            this.btnCalcular.Click += new System.EventHandler(this.BtnCalcular_Click);
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(608, 168);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(94, 47);
            this.btnLimpar.TabIndex = 7;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(608, 235);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(94, 47);
            this.btnSair.TabIndex = 8;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // errorProvider2
            // 
            this.errorProvider2.ContainerControl = this;
            // 
            // errorProvider3
            // 
            this.errorProvider3.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1261, 450);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.btnCalcular);
            this.Controls.Add(this.mskdboxLadoc);
            this.Controls.Add(this.lblLadoc);
            this.Controls.Add(this.mskdboxLadob);
            this.Controls.Add(this.lblLadob);
            this.Controls.Add(this.mskdboxLadoa);
            this.Controls.Add(this.lblLadoa);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Validated += new System.EventHandler(this.Form1_Validated);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider3)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblLadoa;
        private System.Windows.Forms.MaskedTextBox mskdboxLadoa;
        private System.Windows.Forms.MaskedTextBox mskdboxLadob;
        private System.Windows.Forms.Label lblLadob;
        private System.Windows.Forms.MaskedTextBox mskdboxLadoc;
        private System.Windows.Forms.Label lblLadoc;
        private System.Windows.Forms.Button btnCalcular;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.ErrorProvider errorProvider1;
        private System.Windows.Forms.ErrorProvider errorProvider2;
        private System.Windows.Forms.ErrorProvider errorProvider3;
    }
}

