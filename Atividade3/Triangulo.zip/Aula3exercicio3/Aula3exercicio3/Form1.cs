﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula3exercicio3
{


    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private void MskdboxLadoa_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(mskdboxLadoa, "");
            double Ladoa;

            if (!double.TryParse(mskdboxLadoa.Text, out Ladoa)) {

                errorProvider1.SetError(mskdboxLadoa, "Valor de A inválido");
                        }
        }

        private void MskdboxLadob_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(mskdboxLadob, "");
            double Ladob;

            if (!double.TryParse(mskdboxLadob.Text, out Ladob))
            {

                errorProvider1.SetError(mskdboxLadob, "Valor de B inválido");
            }
        }

        private void MskdboxLadoc_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(mskdboxLadoc, "");
            double Ladoc;

            if (!double.TryParse(mskdboxLadoc.Text, out Ladoc))
            {

                errorProvider1.SetError(mskdboxLadoc, "Valor de C inválido");
            }
        }

        private void Form1_Validated(object sender, EventArgs e) 
        {
           

        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            double ladoa, ladob, ladoc;


            if (!double.TryParse(mskdboxLadoa.Text, out ladoa) || !double.TryParse(mskdboxLadob.Text, out ladob) ||
                !double.TryParse(mskdboxLadoc.Text, out ladoc))
            {
                MessageBox.Show("valores devem ser numericos");
            }
            else if (ladoa < (ladob + ladoc) && ladoa > Math.Abs(ladob - ladoc)
                    && ladob < (ladoa + ladoc) && ladob > Math.Abs(ladoa - ladoc)
                    && ladoc < (ladob + ladoa) && ladoc > Math.Abs(ladoa - ladob))
            {
                if (ladoa == ladob && ladoc == ladob)
                {
                    MessageBox.Show("Triangulo Equilátero");
                }

                else if (ladoa == ladob || ladoa == ladob || ladob == ladoc)
                {
                    MessageBox.Show("Triangulo Isósceles");
                }
                else
                {
                    MessageBox.Show("Triangulo Escaleno");
                }

            }
            else
            {
                MessageBox.Show("Não forma um triangulo");
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskdboxLadoa.Clear();
            mskdboxLadob.Clear();
            mskdboxLadoc.Clear();
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
