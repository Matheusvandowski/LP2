﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace imc1
{
    public partial class Form1 : Form
    {

        double altura, peso, imc;

        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (!double.TryParse(txtAltura.Text, out altura))
            {
                MessageBox.Show("Altura invalida");
                txtAltura.Focus();
            }
            else if (!double.TryParse(txtPeso.Text, out peso))
            {
                MessageBox.Show("Peso invalida");
                txtPeso.Focus();
            }
            else
            {
                double imc;
                imc = peso / (altura * altura);
                imc = Math.Round(imc, 1);

                if (imc < 18.5) 
                {
                    MessageBox.Show(" Seu peso é de Magreza");
                }

                else if (imc < 24.9)
                {
                    MessageBox.Show("Seu peso é Normal");
                }   
                    

                else if (imc < 29.9)
                {
                     MessageBox.Show("Seu peso é SobrePeso");
                }   
                                                      
                else if (imc < 39.9)
                {
                     MessageBox.Show("Seu peso é Obesidade");

                }
                   
                else 
                {
                     MessageBox.Show("Seu peso é Obesidade Grave");
                }
               
                                
            }


        }

        private void textBox1_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAltura.Text,out altura) )
                MessageBox.Show("Altura invalida");
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {

        }
    }
}




