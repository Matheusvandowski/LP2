﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado; // globais 

        private void TxtNum1_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtNum1.Text, out numero1))
            {
                MessageBox.Show("numero 1 inválido");
                txtNum1.Focus();
            }
        }

        private void TxtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out numero2))
            {
                MessageBox.Show("numero 2 inválido");
                txtNum2.Focus();
            }
        }

        private void Btnplus_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString();

        }

        private void Btnminus_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void Btnmult_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString();
        }

        private void Btndiv_Click(object sender, EventArgs e)
        {
            if (numero2 == 0)
            {
                MessageBox.Show("Não dividirás por zero!", "Tente outra VEz", 
                MessageBoxButtons.OK, MessageBoxIcon.Error);
                txtNum2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString();
            }
        }

        private void Btnsair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Você vai me abandonar :( ?", "Saída", MessageBoxButtons.YesNo,
                MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Btnlimpar_Click(object sender, EventArgs e)
        {   
            

            txtNum1.Focus();
            resultado = 0;
            numero1 = 0;
            numero2 = 0;

            txtNum1.Clear();
            txtNum2.Clear();
            txtResultado.Clear();
        }
    }
}
